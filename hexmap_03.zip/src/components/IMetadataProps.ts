export interface IMetadataProps {
    title: string,
    source: string
}