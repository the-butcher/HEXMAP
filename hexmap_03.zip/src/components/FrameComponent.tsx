import { IMapProps } from "./IMapProps";


function FrameComponent(props: IMapProps) {

    const { metadataProps } = { ...props };

    return (

        <div
            style={{
                position: 'absolute',
                left: '4vw',
                right: '4vw',
                top: '4vw',
                bottom: '4vw',
                pointerEvents: 'none',
                color: 'var(--color-text)',
                border: '1px solid var(--color-text)',
                fontFamily: 'var(--font-text)'

            }}
        >
            <div
                style={{
                    position: 'absolute',
                    left: '1vw',
                    top: '0.3vw',
                    fontSize: '8vmin'
                }}
            >
                Austria
            </div>
            <div
                style={{
                    position: 'absolute',
                    left: '1.2vw',
                    top: '4.0vw',
                    fontSize: '3vmin'
                }}
            >
                {metadataProps.title}
            </div>
            <div
                style={{
                    position: 'absolute',
                    left: '1vw',
                    bottom: '-0.2vw',
                    fontSize: '2vmin'
                }}
            >
                <pre>{metadataProps.source}</pre>
            </div>
            <div
                style={{
                    position: 'absolute',
                    right: '1vw',
                    bottom: '-0.2vw',
                    fontSize: '2vmin',
                    whiteSpace: 'pre-wrap'
                }}
            >
                <pre>@FleischerHannes</pre>
            </div>

        </div >

    );

}

export default FrameComponent;