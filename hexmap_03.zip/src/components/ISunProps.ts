export interface ISunProps {
  sunriseInstant: number;
  sunsetInstant: number;
  sunInstant: number;
}
