export interface IHexagonBorders {

    i: number;
    path: string;
    b030?: boolean;
    b090?: boolean;
    b150?: boolean;
    b210?: boolean;
    b270?: boolean;
    b330?: boolean;

}