import { Loader } from 'three';

export class PbfLoader extends Loader {


    
}