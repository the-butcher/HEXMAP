import { IAppAction } from "./IAppAction";

export interface IAppState {
    action: IAppAction;
}