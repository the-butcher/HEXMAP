export interface IInterpolatedValue {

    getOut(val: number): number;

}