export interface IRange {
    min: number;
    max: number;
}