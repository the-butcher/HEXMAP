import { IHexagon } from "../components/IHexagon";

export interface IColorScale {
    toH: (value: number) => number;
    toS: (value: number) => number;
    toV: (value: number) => number;
    toRgba: (hexagon: IHexagon) => number[];
}