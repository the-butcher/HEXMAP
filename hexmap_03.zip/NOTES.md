- population data :: https://data.jrc.ec.europa.eu/dataset/2ff68a52-5b5b-4a22-8f40-c41da8332cfe
  GHS-POP R2023A - GHS population grid multitemporal (1975-2030)

- some kind of layout / map frame
- find things that may improve performance

  - shadow settings, ...
  - transparency
  - maybe reduce shadow parameters (or use different lights) during animation

- create some alias concept for the data below

MISSING DATA:
40835 - PEUERBACH
=
40819 - Peuerbach
40803 - Bruck-Waasen

MISSING DATA:
70370 - MATREI
=
70330 - Mühlbachl
70341 - Pfons

MISSING DATA:
61060 - Sankt Veit Südsteiermark
=
61056 - Sankt Veit Südsteiermark

MISSING DATA:
61061 - Strass in Steiermark
=
61058 - Strass in Steiermark
62347 -

MISSING DATA:
41346 - St.Stefan-Alfiesl
=
41301 - Alfiesl
41335 - St.Stefan am Walde

# 41345 - Helfenberg

41310 - Helfenberg
41302 - Ahorn

# 41628 - Vorderweißenbach

41340 - Schönegg
41625 - Vorderweißenbach
